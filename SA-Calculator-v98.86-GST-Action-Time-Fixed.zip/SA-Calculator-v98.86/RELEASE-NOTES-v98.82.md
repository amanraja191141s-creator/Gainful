# SA Calculator v98.82 — GST & keypad precision update

## Changes
- Corrected GST-inclusive / GST-exclusive result semantics.
- Added explicit Taxable Amount and Gross Amount (including GST) output rows.
- Dynamic amount-field label now clarifies whether the entered amount includes GST.
- GST rate validation now follows the recording's `<40%` rule at both entry and calculation.
- GST AC and Backspace restore an empty field instead of leaving a literal zero.
- GST amount and rate entry are limited to two decimal places.
- Missing GST amount/rate now prompts the user and keeps the keypad open rather than committing an empty result.
- Preserved the shared 4×4 numeric keypad and tall equals key; resolved the landscape max-height conflict.
- Added regression coverage for the GST flow, keypad geometry and expression/result state restoration.
- Updated package, PWA, service-worker cache namespace and Android workflow release identity to v98.82.

## GST example from the supplied recording
For ₹5,956 entered in Without GST mode at 9%:
- GST: ₹491.78
- Taxable amount: ₹5,464.22
- Gross amount including GST: ₹5,956.00

For ₹5,956 entered in With GST mode at 9%:
- Taxable amount: ₹5,956.00
- GST: ₹536.04
- Gross amount including GST: ₹6,492.04
